---
created: 2026-03-18
last_verified: 2026-03-18
next_action: null
origin_session: manual
source: agent-generated
status: complete
trust: medium
type: implementation-plan
category: build
---

# Implementation Plan: Codex Desktop Bootstrap Support

## Goals

Improve Codex desktop's ability to enter a memory-backed repository in the right state automatically instead of depending on manual bootstrap discipline every session. The target outcome is a repo-declared startup manifest that lets Codex load the compact returning-session context, detect first-run vs. returning-session flows, and surface the right files before work begins.

This plan is about app support, not changes to this repo's memory contents. The deliverable is a concrete product and implementation roadmap for Codex desktop.

---

## Problem statement

Today, memory-system effectiveness depends on the agent correctly discovering and following bootstrap instructions in repo files such as `README.md`, `meta/quick-reference.md`, and folder summaries. That works, but it is fragile:

- the app does not know which files are canonical startup context
- detached worktrees and branch drift are invisible until the agent checks manually
- compact returning-session startup and full bootstrap are repo conventions, not first-class app concepts
- the agent has to spend context budget rediscovering structure the app could have loaded directly

The app should understand a repo's preferred startup route and preload the right context.

---

## Desired capabilities

1. **Repo-declared startup manifest**
   - file or metadata block declaring canonical startup files
   - different manifests for first run, returning session, periodic review, and automation runs
   - explicit precedence over ad hoc agent heuristics

2. **Bootstrap mode detection**
   - detect first run vs. returning session
   - detect automation run vs. interactive thread
   - detect detached HEAD vs. branch-bound worktree before work starts

3. **Context-budget-aware loading**
   - load compact startup set by default
   - allow the repo to declare "read only on first exposure" files
   - show the agent what was preloaded so retrieval remains auditable

4. **UI surfacing**
   - startup panel showing which repo files were loaded and why
   - one-click open for canonical startup files
   - explicit handoff from preload state into active task execution

---

## Research and design phases

### Phase 1 — Startup manifest contract · ☑ 3/3 complete

1. ☑ Define a repo-level manifest format
   - decision: use a repo-owned root file, `agent-bootstrap.toml`; Codex may cache derived state app-side, but the repo file is the preload authority
   - support named modes: `first_run`, `returning`, `automation`, `periodic_review`
   - each step records `path`, `role`, `required`, `skip_if`, and `cost` so preload order is explicit and context-aware

2. ☑ Define fallback behavior when the manifest is missing or incomplete
   - safe defaults for generic repos: `AGENTS.md` if present, otherwise `README.md`, then task-driven retrieval
   - memory-repo heuristic: if `meta/quick-reference.md` plus `identity/`, `plans/`, `knowledge/`, and `chats/` exist, treat that file as the router and infer compact-returning preload behavior
   - conflict rule: the manifest controls preload order, but Codex surfaces disagreements with repo docs as a startup warning instead of silently guessing

3. ☑ Define compatibility with existing memory repos
   - zero-break migration: repos without `agent-bootstrap.toml` continue to rely on Markdown routing until they opt in
   - adapter-file rule: `AGENTS.md`, `.cursorrules`, and `CLAUDE.md` are treated as platform shims that may point to the router or add platform-specific constraints, but they should not become competing startup authorities

### Phase 1 decisions (2026-03-18)

#### 1. Bootstrap surface

The bootstrap contract should be repo-declared and layered:

- **Router**: one canonical Markdown file that chooses the session route (`meta/quick-reference.md` in this repo shape)
- **Manifest**: one machine-readable file that tells Codex what to preload for each mode
- **Adapter shims**: platform-specific files like `AGENTS.md`, `.cursorrules`, and `CLAUDE.md` that point agents toward the router/manifest without redefining the startup graph

This keeps repo authority centralized while still letting different agent platforms expose their own instruction surfaces.

#### 2. Manifest shape

Use a root `agent-bootstrap.toml` with named modes and ordered steps. Minimal draft:

```toml
version = 1
router = "meta/quick-reference.md"
default_mode = "returning"

adapter_files = ["AGENTS.md", "CLAUDE.md", ".cursorrules"]

[[modes.returning.steps]]
path = "meta/quick-reference.md"
role = "router"
required = true
cost = "light"

[[modes.returning.steps]]
path = "identity/SUMMARY.md"
role = "identity-summary"
required = true
cost = "light"

[[modes.returning.steps]]
path = "chats/SUMMARY.md"
role = "chat-summary"
required = false
skip_if = "placeholder_or_empty"
cost = "light"

[[modes.returning.steps]]
path = "plans/SUMMARY.md"
role = "plan-summary"
required = false
skip_if = "no_active_plans"
cost = "light"

[[modes.returning.steps]]
path = "scratchpad/USER.md"
role = "scratchpad-user"
required = false
skip_if = "placeholder_or_empty"
cost = "light"

[[modes.returning.steps]]
path = "scratchpad/CURRENT.md"
role = "scratchpad-current"
required = false
skip_if = "placeholder_or_empty"
cost = "light"
```

Deliberately keep the first version small. The manifest should declare preload order and skip rules, not become a second policy engine.

#### 3. Fallback model

When no manifest exists, Codex should fall back in this order:

1. Read `AGENTS.md` if present and follow any startup pointer it contains.
2. Otherwise read `README.md`.
3. If the repo matches the memory-repo shape (`meta/quick-reference.md`, folder summaries, `ACCESS.jsonl` files), infer the compact returning flow instead of doing an indiscriminate bootstrap.
4. If the shape is unknown, stay generic: load the lightest authority file available, then shift to task-driven retrieval.

When the manifest is present but incomplete, Codex should trust the declared steps first, then fill missing pieces with the same heuristics and label those additions as inferred.

#### 4. Compatibility and precedence

- The manifest is opt-in. Existing repos remain functional without it.
- Codex should offer migration help by previewing an inferred manifest, but must not write one automatically.
- Platform adapters remain valid, but the manifest is the only preload contract Codex treats as authoritative.
- If Markdown instructions disagree with the manifest, Codex should preserve audibility by warning and showing both sources rather than silently picking one.

This preserves consistency and keeps preload behavior reviewable in git.

### Phase 2 prototype decisions (2026-03-18)

#### 1. Mode detection precedence

Codex should resolve startup mode in this order:

1. **Automation** when thread metadata says the run is scheduled or recurring.
2. **Periodic review** when the task itself is a governance review or review automation.
3. **First run** when the repo is blank or template-backed and there is no real chat history yet.
4. **Full bootstrap** when the repo is clearly returning, but the current thread is a fresh instantiation or the user explicitly asks for the full governance stack.
5. **Returning** otherwise.

Repo-side prototype: `agent-bootstrap.toml` now records the named modes plus the branch/worktree warnings the app should surface before work starts.

#### 2. Deterministic preload ordering

The manifest should be the ordered preload contract. Runtime behavior should:

- normalize and canonicalize paths before deduplication
- preserve the first declared occurrence of a file and drop later duplicates
- emit a startup trace with one record per declared step: `loaded`, `skipped`, or `missing`
- preserve explicit skip reasons such as `placeholder_or_empty`, `no_active_plans`, user override, or budget pressure

Repo-side prototype: added `agent-bootstrap.toml` and validator coverage so the machine-readable startup graph stays aligned with `meta/quick-reference.md`, adapter files, README copy, and setup artifacts.

#### 3. Budgeting and preload auditability

Use per-mode token ceilings as hints, not hard failures:

- returning / automation: **7k**
- first run: **20k**
- full bootstrap / periodic review: **25k**

When the budget is tight, summaries beat transcripts and metadata probes beat deeper governance files. Preloaded files should be visible in the startup trace, but they should **not** automatically become ACCESS retrievals by default; explicit file opens remain the auditable retrieval boundary for this repo unless a repo opts into preload logging.

Repo-side prototype: `HUMANS/tooling/scripts/resolve_bootstrap_manifest.py` now models compact-context pressure directly instead of treating token budgets as inert metadata. The runtime prototype now:

- estimates preload cost from each step's declared `cost`
- reserves a slice of the mode budget so optional higher-cost files can be skipped before compact context is exhausted
- marks skipped optional steps with `reason = "budget_pressure"` in the startup trace
- treats transcript files as heavy when `prefer_summaries = true`, so summaries win under tight budgets without requiring the repo to hand-tune every transcript cost
- returns explicit budget state (`limit`, `reserve`, `estimated_used`, `estimated_remaining`, `pressure`) plus `preload_access_mode = "startup_trace_only"` so preload auditing stays separate from ACCESS retrieval logs

### Phase 2 — Startup runtime and detection logic · ☑ 3/3 complete

4. ☑ Implement startup mode detection
   - first-run vs. returning-session checks
   - branch/worktree state checks
   - automation run detection from thread metadata

5. ☑ Implement deterministic preload ordering
   - preserve repo-declared order
   - deduplicate equivalent files
   - mark skipped files and the reason they were skipped

6. ☑ Add compact-context budgeting rules
   - max file count / token budget hints
   - explicit "load summaries before transcripts" behavior
   - preserve an access trail for preloaded files

### Phase 3 — Desktop UX · ☑ 3/3 complete

7. ☑ Design the startup panel
   - files loaded
   - mode selected
   - repo-declared next step

8. ☑ Add branch/worktree warnings to startup
   - detached HEAD
   - worktree not aligned with requested branch
   - branch already checked out in another worktree

9. ☑ Add manual override controls
   - "load full bootstrap"
   - "load compact startup only"
   - "skip repo manifest for this thread"

### Phase 3 decisions (2026-03-18)

#### 1. The startup panel should be a structured summary, not just a raw file trace

The bootstrap runtime already knows enough to produce the core startup UI contract. The app should not reconstruct the panel ad hoc from loosely related fields. Instead, the startup resolution should include a dedicated panel object that directly answers the user-facing questions:

- which startup mode was selected
- whether startup is ready or needs attention
- what files were loaded, skipped, or missing
- what the repo-declared next step is

Repo-side prototype: `HUMANS/tooling/scripts/resolve_bootstrap_manifest.py` now returns a `startup_panel` object alongside the lower-level startup trace.

#### 2. The panel should anchor the next step to the repo router

The most stable repo-declared next action is the router itself, not an inferred ad hoc message from the app. In this repo shape, the panel's primary action should point to `meta/quick-reference.md` as the canonical startup handoff for the selected mode. That keeps authority with the repo and gives the app a one-click action without inventing a second startup authority.

#### 3. The panel status should be driven by real startup risk signals

The panel should surface a compact status rather than making the user parse warnings manually:

- `ready` when startup loaded cleanly with no warnings
- `attention` when git/worktree warnings exist, required files are missing, or budget pressure changed what was preloaded

Repo-side prototype: the runtime now derives `startup_panel.status`, file counts, warning count, budget health, and a panel-friendly file list from the same startup resolution used by the trace and warning system. `HUMANS/tooling/tests/test_bootstrap_resolver.py` validates both the ready and attention paths.

#### 4. Branch and worktree warnings should be first-class panel content

Changing the panel status to `attention` is not enough. The startup panel should carry structured warning rows for the three git/worktree hazards the plan calls out:

- detached HEAD
- current worktree not aligned with the requested branch
- target branch already checked out in another worktree

Those warnings should remain explicit in the panel even though the lower-level startup resolution already has a generic warning list. The UI contract needs titles, source classification, and stable codes so the app can render them directly instead of reinterpreting raw warning text.

Repo-side prototype: `HUMANS/tooling/scripts/resolve_bootstrap_manifest.py` now maps startup warnings into `startup_panel.warnings`, with explicit git-sourced warning entries for detached HEAD, branch drift, and branch-checked-out-elsewhere. `HUMANS/tooling/tests/test_bootstrap_resolver.py` validates both single-warning and all-warning panel states.

#### 5. Manual override controls are a first-class startup panel contract, not CLI flags

The three override actions ("Load Full Bootstrap", "Load Compact Startup Only", "Skip Repo Manifest") are always present in `startup_panel.available_overrides` so the UI can render them as buttons without additional runtime logic. At most one has `active=True`, making the panel self-describing: the app knows which override (if any) is in effect without parsing mode names or source strings.

The overrides map onto runtime behavior as follows:

- `full_bootstrap` — sets `full_bootstrap=True` internally; the manifest is still read and the full-bootstrap mode steps are used
- `compact_only` — forces `requested_mode="returning"` regardless of what auto-detection would have chosen, even on a first-run or periodic-review shape
- `skip_manifest` — bypasses `agent-bootstrap.toml` entirely and falls back to AGENTS.md → README.md; always emits a `manifest_skipped` warning (source: `user_override`) so the panel shows `attention` and the user can see the bypass clearly

`StartupResolution.active_override` and `StartupPanel.active_override` carry the override identifier for machine-readable callers. The CLI gains `--override {full_bootstrap,compact_only,skip_manifest}` so the prototype can be exercised directly.

Repo-side prototype: `resolve_bootstrap_manifest.py` now accepts `user_override`, routes `skip_manifest` through a dedicated `_resolve_skip_manifest()` helper, and always populates `available_overrides` with all three controls. `test_bootstrap_resolver.py` validates each override type plus the no-override baseline (5 new tests, 14 total passing).

### Phase 4 — Validation and rollout · ☑ 2/2 complete

10. ☑ Define test matrix
   - fresh clone
   - mature memory repo
   - detached automation worktree
   - malformed manifest

11. ☑ Draft rollout strategy
   - behind feature flag first
   - support repo opt-in before default-on
   - telemetry on preload usefulness and skipped-file rates

### Phase 4 test matrix decisions (2026-03-18)

| Scenario | What the app/runtime must prove | Current repo coverage | Exit signal |
|---|---|---|---|
| Fresh clone / blank or template-backed repo | First-run detection wins, first-run preload stays explicit, and returning-only context does not leak into the startup set. | `test_automation_mode_beats_other_detection_routes`, `test_first_run_detection_uses_template_identity_and_no_chat_history`, validator baseline in `HUMANS/tooling/tests/test_validate_memory_repo.py` | `resolve_startup(...).mode == "first_run"` and the first-run manifest steps load in order |
| Mature memory repo | Returning and full-bootstrap paths preserve compact preload order, skip placeholders or inactive plan surfaces correctly, and keep override state auditable. | `test_returning_trace_skips_placeholders_and_no_active_plans`, `test_override_full_bootstrap_forces_full_bootstrap_mode`, `test_no_override_leaves_active_override_none_with_all_controls_inactive` | Startup trace order, panel counts, and override state all match the declared manifest contract |
| Detached automation worktree | Automation mode still wins, but the startup panel blocks silent drift by surfacing detached HEAD and branch-drift warnings before work begins. | `test_automation_mode_beats_other_detection_routes`, `test_automation_mode_surfaces_detached_worktree_attention` | `mode == "automation"` with explicit git warning rows and `startup_panel.status == "attention"` |
| Malformed manifest | Invalid repo declarations are rejected before the runtime treats them as executable startup authority. | `test_missing_bootstrap_manifest_fails`, `test_bootstrap_manifest_with_wrong_router_fails`, `test_bootstrap_manifest_with_wrong_returning_order_fails` in `HUMANS/tooling/tests/test_validate_memory_repo.py` | Validator rejects missing manifests, wrong router authority, and wrong ordered step sets |

Resolver behavior should stay intentionally separate from manifest-validation behavior. The runtime prototype may assume `agent-bootstrap.toml` already passed validation; malformed-manifest cases belong in validator coverage, not ad hoc resolver fallbacks.

### Phase 4 rollout strategy decisions (2026-03-18)

The rollout should stay deliberately staged so Codex desktop can learn from real repos without silently taking over startup behavior.

| Stage | Scope | Guardrails | Exit signal |
|---|---|---|---|
| 0. Repo-side prototype | Keep `agent-bootstrap.toml`, the bootstrap resolver, and validator checks in-repo only. Use this stage to harden manifest semantics and startup-panel shape before any product integration. | No app behavior changes yet; the repo remains the only place where the contract is exercised. | Resolver + validator stay aligned, and the startup-panel contract is stable across the defined test matrix. |
| 1. Desktop beta behind feature flag | Add bootstrap support to Codex desktop behind an app feature flag. Read manifests only for flagged users and surface the startup panel as an inspectable preview before auto-preload becomes default behavior. | Feature flag off by default; no silent manifest writes; keep manual override controls and warning surfacing mandatory. | Beta users can resolve startup mode and inspect preload traces without regressions in repo authority or startup clarity. |
| 2. Repo opt-in rollout | Allow any repo with a valid `agent-bootstrap.toml` to opt into startup-manifest support while non-participating repos keep the existing heuristic path. | Manifest presence is required for productized preload behavior; invalid manifests fail closed into existing startup heuristics with explicit warnings. | Opt-in repos show stable preload ordering, warning delivery, and override usage without requiring app-side per-repo customization. |
| 3. Broader default-aware adoption | After enough opt-in evidence, teach Codex desktop to treat startup manifests as the preferred contract when present and to offer inferred-manifest migration help for repos that match the memory-repo shape. | Default-on only for repos that declare the contract; heuristic inference remains advisory and reviewable, never silent authority. | Startup usefulness telemetry is positive, skipped-file rates are understood, and manifest-backed repos consistently outperform heuristic startup on clarity and repeatability. |

Telemetry should focus on whether preload behavior is actually helping, not just whether the feature ran:

- mode-selection accuracy signals: override frequency, manifest-skipped sessions, and user re-routing immediately after startup
- preload usefulness signals: router open rate, startup-panel interaction rate, and whether users expand into the recommended next file
- preload cost signals: estimated budget pressure frequency, optional-step skip rates, and transcript-vs-summary suppression frequency
- startup risk signals: detached HEAD / branch-drift warning rates, required-file missing rates, and malformed-manifest validation failures

Release gates for moving beyond opt-in:

- manifest-backed startup must remain auditable: loaded, skipped, inferred, and overridden state all visible in the startup panel
- startup preload must not materially exceed the published compact/full context budget bands for seeded memory repos
- invalid manifests must fail closed into existing startup heuristics instead of producing partial silent behavior
- the app must preserve repo authority: the router and manifest stay reviewable in git, and Codex does not auto-author repo startup contracts

---

## Open questions

- Should preloaded files automatically count as retrievals for memory systems that track access?
- How much startup state should be visible to the user vs. kept agent-facing only?
- Should task-classified on-demand context (for example `knowledge/SUMMARY.md`) remain heuristic, or should manifests be allowed to declare conditional task expansions too?

---

## Progress log

| Date | Action |
|---|---|
| 2026-03-18 | Plan created from identified Codex desktop gap: memory-aware repo startup and bootstrap loading |
| 2026-03-18 | Completed Phase 1 contract definition: chose a repo-owned `agent-bootstrap.toml`, defined fallback and conflict rules, and formalized adapter-file precedence |
| 2026-03-18 | Added a repo-local `agent-bootstrap.toml` prototype plus validator-backed checks, and defined mode detection precedence, dedup semantics, budget hints, and preload-audit defaults for Phase 2 |
| 2026-03-18 | Added `HUMANS/tooling/scripts/resolve_bootstrap_manifest.py` plus tests as an executable runtime prototype for mode detection, git/worktree warnings, deterministic preload traces, and skip-reason reporting |
| 2026-03-18 | Added budget-aware preload resolution to the bootstrap runtime prototype, including reserve-based optional-step skipping, transcript-heavy summary preference, explicit budget state, and trace-only preload auditing |
| 2026-03-18 | Completed Add compact-context budgeting rules (codex-desktop-bootstrap-support 6/11) |
| 2026-03-18 | Added a structured startup-panel contract to the bootstrap runtime prototype, with mode/status summary, panel-friendly file rows, router-anchored next step, and derived warning/budget state |
| 2026-03-18 | Completed Design the startup panel (codex-desktop-bootstrap-support 7/11) |
| 2026-03-18 | Added structured branch/worktree warning rows to the startup panel contract, covering detached HEAD, branch drift, and branch-checked-out-elsewhere states |
| 2026-03-18 | Completed Add branch/worktree warnings to startup (codex-desktop-bootstrap-support 8/11) |
| 2026-03-18 | Added manual override controls: `user_override` param routes full_bootstrap/compact_only through detect_mode and skip_manifest through a dedicated fallback path; all three controls always present in startup_panel.available_overrides; 5 new tests (14 total passing) |
| 2026-03-18 | Completed Add manual override controls (codex-desktop-bootstrap-support 9/11) |
| 2026-03-18 | Defined the Phase 4 test matrix across fresh-clone, mature-repo, detached-automation-worktree, and malformed-manifest scenarios; added detached automation worktree coverage to the bootstrap resolver tests and advanced the plan to 10/11 |
| 2026-03-18 | Completed Draft rollout strategy (codex-desktop-bootstrap-support 11/11) |

---

## Notes

- This plan pairs closely with `codex-desktop-automation-continuity.md` because automations need a specialized startup mode.
- The most important constraint is preserving repo authority: the app should amplify the repo's bootstrap contract, not silently replace it.